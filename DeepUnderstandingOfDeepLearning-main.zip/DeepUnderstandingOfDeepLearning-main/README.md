# Deep Understanding Of Deep Learning
Python code accompanying the course "A deep understanding of deep learning (with Python intro)"

Master deep learning in PyTorch using an experimental scientific approach, with lots of examples and practice problems.


See https://www.udemy.com/course/deeplearning_x/?couponCode=202302 for more details, preview videos, and to enroll in the full course.

